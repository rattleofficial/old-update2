
import os
while True:
    file=open(os.getcwd()+'/wordlist.txt','r')

    a=input('Enter your password to be check:')


    if a in file.read():
        print('breakable')
        
    else:
        print('strong')
    
